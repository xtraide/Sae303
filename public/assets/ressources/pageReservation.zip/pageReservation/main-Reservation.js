// Premier carrousel
let index = 0;

function bouger(direction) {
  const contenu = document.querySelector('.carrousel-contenu');
  const totalContenus = document.querySelectorAll('.carrousel-contenu > div').length;

  index = (index + direction + totalContenus) % totalContenus;
  contenu.style.transform = `translateX(-${index * 100}%)`;
}


// Deuxième carrousel
let index02 = 0;

function bouger02(direction) {
  const contenu02 = document.querySelector('.carrousel-contenu02');
  const totalContenus02 = document.querySelectorAll('.carrousel-contenu02 > div').length;

  index02 = (index02 + direction + totalContenus02) % totalContenus02;
  contenu02.style.transform = `translateX(-${index02 * 100}%)`;
}

// Date Input
document.addEventListener('DOMContentLoaded', function() {
  var today = new Date().toISOString().split('T')[0]; 
  document.getElementById("dateInput").setAttribute("min", today); 
});
