<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="main-Reservation.css" />
  </head>
  <body>
    <section id="main_Antoine_v03">
      <h1>MA COMMANDE</h1>

    <div id="mohaha">

        <div>
           <h2>Aéronefs</h2> 

        <div id="card01">
                    <div id="monCarrousel" class="carrousel">
                        <div class="carrousel-contenu">
                            <div class="divsoso">
                                <img src="./img/Autogire.png" alt="">
                                <div class="divVehicule"><h3>Autogire</h3></div>
                            </div>
                            <div class="divsoso">
                                <img src="./img/Baloon.png" alt="">
                                <div class="divVehicule"><h3>Baloon</h3></div>
                            </div>
                            <div class="divsoso">
                                <img src="./img/HelicoLeger.png" alt="">
                                <div class="divVehicule"><h3>Helicoptère</h3></div>
                            </div>
                            <div class="divsoso">
                                <img src="./img/Multiaxes.png" alt="">
                                <div class="divVehicule"><h3>Multiaxes</h3></div>
                            </div>
                            <div class="divsoso">
                                <img src="./img/Paramoteur.png" alt="">
                                <div class="divVehicule"><h3>Paramoteur</h3></div>
                            </div class="divVehicule">
                            <div class="divsoso">
                                <img src="./img/Pendulaire.png" alt="">
                                <div class="divVehicule"><h3>Pendulaire</h3></div>
                            </div class="divVehicule">

                            <!-- Ajoutez plus de divs de contenu ici -->
                        </div>
                        <button class="precedent" onclick="bouger(-1)">&#10094;</button>
                        <button class="suivant" onclick="bouger(1)">&#10095;</button>
                    </div>
                </div>
        </div>
        
        <div>
            <h2>Forfaits</h2>

            <div id="card02">
            <div id="monCarrousel02" class="carrousel02">
                <div class="carrousel-contenu02">
                    <div class="divsoso">
                        <img src="./img/CardSix.png" alt="">
                        <div class="divVehicule02"><h3>Forfait BRONZE</h3></div>
                    </div>
                    <div class="divsoso">
                        <img src="./img/CardFive.png" alt="">
                        <div class="divVehicule02"><h3>Forfait ARGENT</h3></div>
                    </div>
                    <div class="divsoso">
                        <img src="./img/CardFour.png" alt="">
                        <div class="divVehicule02"><h3>Forfait OR</h3></div>
                    </div>
                    <div class="divsoso">
                        <img src="./img/CardOne.png" alt="">
                        <div class="divVehicule02"><h3>Abonnement ESSENTIEL</h3></div>
                    </div>
                    <div class="divsoso">
                        <img src="./img/CardTwo.png" alt="">
                        <div class="divVehicule02"><h3>Abonnement PREMIUM</h3></div>
                    </div class="divVehicule">
                    <div class="divsoso">
                        <img src="./img/CardThree.png" alt="">
                        <div class="divVehicule02"><h3>Abonnement ELITE</h3></div>
                    </div class="divVehicule">

                    <!-- Ajoutez plus de divs de contenu ici -->
                </div>
                <button class="precedent02" onclick="bouger02(-1)">&#10094;</button>
                <button class="suivant02" onclick="bouger02(1)">&#10095;</button>
            </div>
        </div>
        </div>
    </div>
    <h2>Date de Reservation</h2>
    <div  id="Card03">
        <form action="">
        <label for="dateInput">Ma prochaine heure de vol :</label>
        <br>
        <input type="date" name="dateInput" id="dateInput">

        <label for="timeInput"></label>
        <input type="time" id="timeInput" list="timeOptions" name="timeInput">
        <datalist id="timeOptions">
            <option value="08:30">
            <option value="10:30">
            <option value="14:30">
            <option value="16:30">
        </datalist>

    </form>
    </div>
    

    <button class="button_Antoine" type="submit">VALIDER COMMANDE</button>
    
</section>

    

        
        
        
        

    

    <script src="main-Reservation.js"></script>
  </body>
</html>
